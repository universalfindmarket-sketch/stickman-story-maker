# Stickman Story Maker V2 — free iPhone setup

If the buttons do nothing when you open the HTML file inside ChatGPT or the iPhone Files preview, that preview may not run the app's JavaScript. The app script passes a JavaScript syntax check; try opening it as a real webpage instead.

## Free option: publish it as a private-use webpage with GitHub Pages

1. Open github.com in Safari and create/sign in to a free GitHub account.
2. Create a new repository named `stickman-story-maker` (a public repository is the simplest option for GitHub Pages; do not put private stories or personal information in the repository).
3. In the repository, choose **Add file → Upload files**.
4. Upload `index.html` from this folder and commit the change.
5. Open the repository's **Settings → Pages**.
6. Under **Build and deployment**, choose **Deploy from a branch**, select the `main` branch and `/(root)`, then save.
7. Wait for GitHub Pages to publish the site. Open the Pages URL shown in Settings → Pages in Safari. The buttons should work there.
8. In Safari, tap **Share → Add to Home Screen** if you want an app-like icon.

Note: GitHub Pages websites are public if the repository is public. This prototype does not send story text to a server, but anyone who has the site can use the app. Do not include secrets or personal information in the code or repository.

## What this prototype does / limitations

- Six-step setup: short/long form, Normal/Ancient template, three character profiles, 15/30/45/60 seconds, scene consistency notes, and script.
- Creates simple animated stickman scene previews and uses device speech synthesis when supported.
- It does not use paid APIs.
- MP4/video export and audio mixing depend on browser support; narration is not embedded in the exported video yet.
